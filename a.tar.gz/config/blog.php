<?php
return [
    'title' => 'pest loli',
    'posts-per_page' => 12,
    'uploads' =>[
        'storage'=>'public',
        'webpath'=>'/storage',
    ],
];
