@extends('admin.blog.layouts.dashboard')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">文章列表</h3>
                    </div>
                    <div class="card-body">

                        TODO

                    </div>
                </div>
            </div>
        </div>
    </div>
@stop