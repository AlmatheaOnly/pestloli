<html>
<head>
    <title><?php echo e($post->title); ?></title>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div class="container">
    <h1><?php echo e($post->title); ?></h1>
    <h5><?php echo e($post->published_at); ?></h5>
    <hr>
    <?php echo nl2br(e($post->content)); ?>

    <hr>
    <button class="btn btn-primary" onclick="history.go(-1)">
        « Back
    </button>
</div>
</body>
</html><?php /**PATH /usr/share/nginx/html/resources/views/blog/post.blade.php ENDPATH**/ ?>