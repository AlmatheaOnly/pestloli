<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row page-title-row">
            <div class="col-md-6">
                <h3>标签
                    <small>» 列表</small>
                </h3>
            </div>
            <div class="col-md-6 text-right">
                <a href="<?php echo e(url('admin/blog/tag/create')); ?>" class="btn btn-success btn-md">
                    <i class="fa fa-plus-circle"></i> 新增标签
                </a>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">

                <?php echo $__env->make('admin.blog.partials.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('admin.blog.partials.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <table id="tags-table" class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>标签</th>
                        <th>标题</th>
                        <th class="hidden-sm">副标题</th>
                        <th class="hidden-md">页面图片</th>
                        <th class="hidden-md">描述信息</th>
                        <th class="hidden-md">布局</th>
                        <th class="hidden-sm">排序</th>
                        <th data-sortable="false">操作</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($tag->tag); ?></td>
                            <td><?php echo e($tag->title); ?></td>
                            <td class="hidden-sm"><?php echo e($tag->subtitle); ?></td>
                            <td class="hidden-md"><?php echo e($tag->page_image); ?></td>
                            <td class="hidden-md"><?php echo e($tag->meta_description); ?></td>
                            <td class="hidden-md"><?php echo e($tag->layout); ?></td>
                            <td class="hidden-sm">
                                <?php if($tag->reverse_direction): ?>
                                    逆序
                                <?php else: ?>
                                    升序
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(url('admin/blog/tag/'.$tag->id.'/edit')); ?>" class="btn btn-xs btn-info">
                                    <i class="fa fa-edit"></i> 编辑
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(function () {
            $("#tags-table").DataTable({});
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.blog.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/share/nginx/html/resources/views/admin/blog/tag/index.blade.php ENDPATH**/ ?>